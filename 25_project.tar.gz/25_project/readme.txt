﻿Python anywhere details:
URL : abcc.pythonanywhere.com/Cook
Login : abcc
Password: python
