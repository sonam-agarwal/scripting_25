# -*- coding: utf-8 -*-
# this file is released under public domain and you can use without limitations

#########################################################################
## This is a sample controller
## - index is the default action of any application
## - user is required for authentication and authorizationss
## - download is for downloading files uploaded in the db (does streaming)
#########################################################################
RECIPES_PER_PAGE=10
status = ('Cuisine','Name')
def index():
    form = SQLFORM.factory(
       Field('Search', requires=IS_IN_SET(status)),
       Field('name',default = 'Choose Cuisine/Recipe name'))
       
    if form.process().accepted:
        name1 = form.vars.Search
        name2= form.vars.name
        if name1=='Cuisine':
            redirect(URL('sbc',vars=dict(name2=name2)))
        elif name1=='Name':
            redirect(URL('sbn',vars=dict(name2=name2)))
        elif name2 == 'hii':
            session.flash = "invalid"
    elif form.errors:
        session.flash = 'form has errors'
    return dict(form=form)

def main():
    """
    example action using the internationalization operator T and flash
    rendered by views/default/index.html or views/generic.html

    if you need a simple wiki simply replace the two lines below with:
    return auth.wiki()
    """
    return locals()

def trial():
    return locals()

def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/manage_users (requires membership in
    http://..../[app]/default/user/bulk_register
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    """
    return dict(form=auth())


@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service

@auth.requires_login()
def forum():
    db.blog_post.created_on.default = request.now
    db.blog_post.created_on.writable = False
    db.blog_post.created_on.readable = False
    form = SQLFORM(db.blog_post).process()
    rows = db(db.blog_post).select(orderby=db.blog_post.title.upper())
    return locals()

def show_post():
    post = db.blog_post(request.args(0))
    db.blog_comment.blog_post.default = post.id
    db.blog_comment.blog_post.readable = False
    db.blog_comment.blog_post.writable = False
    form = SQLFORM(db.blog_comment).process()
    comments = db(db.blog_comment.blog_post==post.id).select()
    return locals()

def view_recipe():
    page = request.args(1,cast=int,default=0)
    start = page*RECIPES_PER_PAGE
    stop = start+RECIPES_PER_PAGE
    return dict(rows = db(db.recipe.id==request.args(0)).select(limitby=(start,stop)))

def view_recipe_image():
    page = request.args(1,cast=int,default=0)
    start = page*RECIPES_PER_PAGE
    stop = start+RECIPES_PER_PAGE
    return dict(rows = db(db.recipe.id==request.args(0)).select(limitby=(start,stop)))



def show_recipe():
    page = request.args(0,cast=int,default=0)
    start = page*RECIPES_PER_PAGE
    stop = start+RECIPES_PER_PAGE
    grid=SQLFORM.grid(db.recipe, user_signature=False)
    return locals()


@auth.requires_login()
def display_form():
    db.recipe.Rating.writable = False
    db.recipe.Rating.readable = False
    form = SQLFORM(db.recipe)
    if form.process().accepted:
       session.flash = 'record inserted'
       redirect(URL())
    return dict(form=form)

def edit_form():
    id = request.args(0,cast=int)
    form = SQLFORM(db.recipe,id).process(next='show_recipe')
    return dict(form=form)

status1 = ('Cuisine','Name')
def search():
    form = SQLFORM.factory(
        Field('Recipe_name', requires=IS_NOT_EMPTY()),
        Field('Search', requires=IS_IN_SET(status1)))
    if form.process().accepted:
        #form=db(db.recipe).select(orderby=form
        #name = db.recipeform.vars.Recipe_name
        search_type = form.vars.Search

#status = ('Italian','Chinese','North-indian','South-Indian','Punjabi','Thai')
status = ('Cuisine','Name')
def search_by_cuisine():
    form = SQLFORM.factory(
       Field('name'),
       Field('Search', requires=IS_IN_SET(status)))
    if form.process().accepted:
        name1 = form.vars.Search
        name2= form.vars.name
        if name1=='Cuisine':
            redirect(URL('sbc',vars=dict(name2=name2)))
    elif form.errors:
        session.flash = 'form has errors'
    return dict(form=form)

def sbc():
    name2 = request.vars.name2 or redirect(URL('index'))
    name2 = name2.lower()
    rows = db(db.recipe.Cuisine==name2).select()
    if(len(rows)==0):
         session.flash="Invalid Entry"
         redirect(URL('default','index'))
    return dict(rows=rows)

    
def rec_cmnt():
    rec = db.recipe(request.args(0))
    db.recipe_comment.recipe.default = rec.id
    db.recipe_comment.recipe.readable = False
    db.recipe_comment.recipe.writable = False
    form = SQLFORM(db.recipe_comment).process()
    comments = db(db.recipe_comment.recipe==rec.id).select()
    return locals()

def search_by_name():
    form = SQLFORM.factory(
       Field('Recipe_name', requires=IS_NOT_EMPTY()))
    if form.process().accepted:
        name = form.vars.Recipe_name
        redirect(URL('sbn',vars=dict(name=name)))
    elif form.errors:
        session.flash = 'form has errors'
    return dict(form=form)

def sbn():
        name2 = request.vars.name2 or redirect(URL('index'))
        name2 = name2.lower()
        rows = db(db.recipe.Name==name2).select()
        if(len(rows)==0):
             session.flash="Invalid"
             redirect(URL('default','index'))
        return dict(rows=rows)
   

def search_by_duration():
    page = request.args(0,cast=int,default=0)
    start = page*RECIPES_PER_PAGE
    stop = start+RECIPES_PER_PAGE
    return dict(rows = db(db.recipe).select(orderby = db.recipe.Duration,limitby=(start,stop)))

def latest_recipe():
    page = request.args(0,cast=int,default=0)
    start = page*RECIPES_PER_PAGE
    stop = start+RECIPES_PER_PAGE
    return dict(rows = db(db.recipe).select(orderby =~db.recipe.created_on,limitby=(start,stop)))

def most_voted():
    page = request.args(0,cast=int,default=0)
    start = page*RECIPES_PER_PAGE
    stop = start+RECIPES_PER_PAGE
    return dict(rows = db(db.recipe).select(orderby = db.recipe.Rating,limitby=(start,stop)))

def search_by_user():
    form = SQLFORM.factory(
       Field('User_id', requires=IS_NOT_EMPTY()))
    if form.process().accepted:
        name = form.vars.User_id
        redirect(URL('sbu',vars=dict(name=name)))
    elif form.errors:
        session.flash = 'form has errors'
    return dict(form=form)

def sbu():
    user_id = request.vars.name or redirect(URL('search_by_user'))
    return dict(rows = db(db.recipe.created_by==user_id).select(orderby =~db.recipe.created_on))

def sbid():
    grid=SQLFORM.grid(auth.user)
    return locals()


def vote_recipe():
    id = request.args(0,casr=int)
    direction = request.args(1)
    

def tips_new():
    return locals()

def bamboo_stick_knife_block():
    return locals()

def eggfresh():
    return locals()

def burntrice():
    return locals()

def masonblender():
    return locals()

def freezewine():
    return locals()

def addcelerytobread():
    return locals()

def hullstrawberry():
    return locals()

def honeyoil():
    return locals()

def addicetogetfat():
    return locals()

def huskcorn():
    return locals()

def applepotato():
    return locals()

def applestickers():
    return locals()

def cutcherrytomatoes():
    return locals()

def marshcone():
    return locals()

def microwavelemon():
    return locals()

def piescraps():
    return locals()

def rubbutteronpot():
    return locals()

def saltpotatoes():
    return locals()

def stuffedtomatoesmuffin():
    return locals()

def toasteroven():
    return locals()
